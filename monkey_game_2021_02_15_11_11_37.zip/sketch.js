
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage,stone;
var ground;
var FoodGroup, obstacleGroup
var score
var survivalTime=0;

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  
  // for monkey
  monkey=createSprite(80,315,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale=0.1;

  //for ground
  ground=createSprite(400,350,900,10);
  ground.velocityX=-4;
  ground.x=ground.width/2;
  console.log(ground.x);
  
  monkey.setCollider("rectangle",0,0,400,monkey.height);
  monkey.debug=false;
  
  bananaGroup = createGroup();
  obstacleGroup = createGroup();
  
  survivalTime=0;
  
}


function draw() {

  background(400)
  
  
  stroke("black");
  textSize(20);
  fill("black");
  //survivalTime=Mathceil(framCount/FrameRate());
  text("Survival Time: "+ survivalTime,150,20);
  survivalTime=survivalTime+Math.round(getFrameRate()/60)
   
    
  if(keyDown("space")) {
    monkey.velocityY=-12;
  }
  monkey.velocityY=monkey.velocityY+0.8;
  
  if(ground.x<0){
    ground.x=ground.width/2;
  }
  
  
  monkey.collide(ground);
  
  spawnFood();
  spawnObstacles();
  
  
  drawSprites();
}

function spawnFood(){
  if(frameCount%80===0){
  banana=createSprite(255,200,20,20);
  Math.round(random(10,60));
  banana.addImage("food",bananaImage);
  banana.scale=0.1;
  banana.velocityX=-3
  banana.lifetime=134;
    
    bananaGroup.add(banana);
  }
}

function spawnObstacles(){
  if(frameCount%300===0){
    stone=createSprite(255,315,20,20);
    Math.round(random(10,60));
    stone.addImage("obstacle",obstacleImage);
    stone.scale=0.1;
    stone.velcoityX=-3
    
    obstacleGroup.add(stone);
    
  stone.setCollider("rectangle",0,0,400,stone.height);
  stone.debug=false;
  
     
  }
}



